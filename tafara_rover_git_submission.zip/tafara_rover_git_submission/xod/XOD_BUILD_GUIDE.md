# XOD Build Guide – Tafara Navigation

This is a logic specification, not a compiled XOD project.

## State sequence
`WAIT_AT_A -> COLLECTING -> DRIVE_A_TO_B -> WAIT_AT_B -> OFFLOADING -> TURNAROUND -> DRIVE_B_TO_A -> WAIT_AT_A`

| State | Motor action | Transition |
|---|---|---|
| WAIT_AT_A | Stop | Start collection stage |
| COLLECTING | Stop | Collection timer expires |
| DRIVE_A_TO_B | Both sides forward | Travel timer expires |
| WAIT_AT_B | Stop | Start offload stage |
| OFFLOADING | Stop | Offload timer expires |
| TURNAROUND | Left forward, right reverse | Pivot timer expires |
| DRIVE_B_TO_A | Both sides forward | Return timer expires |
| FAULT_STOP | Stop | Remain stopped |

At startup, outputs OFF and state `WAIT_AT_A`. Physically place the rover at A; software cannot confirm location.

## Provisional pins (common ESP32 DevKit only)
ENA PWM GPIO25; IN1 GPIO26; IN2 GPIO27; ENB PWM GPIO33; IN3 GPIO18; IN4 GPIO19. Verify exact board and pins.

## Placeholder timings
A-to-B 5000 ms; collection wait 30000 ms; offload wait 30000 ms; turnaround 900 ms; B-to-A 5000 ms. Calibrate on the real rover.

Use one state variable. Start each timer once on state entry. Stop motors in wait states and on boot/reset/brownout. Invalid timing config enters `FAULT_STOP`. ESP32 owns motor timing; Node-RED is monitoring only. Publish telemetry to `rover/tafara/telemetry` and stage events to `rover/tafara/event`.

Timed-only control is open-loop and cannot verify arrival. Coordinate collection/offload handshakes with the relevant subsystem owners.
