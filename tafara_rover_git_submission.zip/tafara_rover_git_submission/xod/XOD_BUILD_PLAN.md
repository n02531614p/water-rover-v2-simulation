# XOD build plan - Tafara rover

## Important status
This folder is a visual build plan, not a verified `.xodball` project. XOD's project file stores patch/node/link identifiers and coordinates; creating a valid project requires matching the exact XOD node definitions installed in your IDE. Do not mistake this guide for a compiled XOD project.

## Required behavior
1. Start stopped at Point A.
2. Wait `COLLECT_WAIT_MS` for water collection.
3. Drive forward for `DRIVE_A_TO_B_MS`.
4. Stop at Point B and wait `OFFLOAD_WAIT_MS`.
5. Pivot in place for `TURN_180_MS`.
6. Drive forward (now facing A) for `DRIVE_B_TO_A_MS`.
7. Stop at A and repeat.

## XOD patch layout
Create a project named `tafara-rover-navigation` and keep the main patch named `main`.

Implement a state machine using:
- `xod/core/clock` as the repeating pulse source.
- `xod/core/flip-flop` or a counter/state patch to sequence the five states.
- `xod/core/elapsed` / `xod/core/watch`-style timing nodes available in your installed core library (search the node suggester by name; node names can differ by XOD version).
- `xod/gpio/digital-write` for L298N direction pins.
- `xod/gpio/pwm-write` for ENA and ENB speed control.
- `xod/core/constant-number` (or numeric constants) for speed and duration settings.

Because XOD core node availability varies by version and the ESP32 package may be community-provided, use the supplied Arduino sketch as the reference implementation and source of truth for the state sequence.

## Motor outputs
| Signal | ESP32 pin |
|---|---:|
| Left enable / PWM (ENA) | 25 |
| Left direction IN1 | 26 |
| Left direction IN2 | 27 |
| Right enable / PWM (ENB) | 33 |
| Right direction IN3 | 18 |
| Right direction IN4 | 19 |

Forward: left IN1 HIGH / IN2 LOW; right IN3 HIGH / IN4 LOW.
Reverse: left IN1 LOW / IN2 HIGH; right IN3 LOW / IN4 HIGH.
Pivot: left forward, right reverse.
Stop: both direction inputs LOW and PWM 0.

## Timing defaults (must be calibrated)
- A to B: 5000 ms
- Collection wait at A: 30000 ms
- B to A: 5000 ms
- Offload wait at B: 30000 ms
- 180-degree pivot: 900 ms

No sensors means the rover cannot detect actual arrival or obstacles. It estimates position from elapsed time only.
