# Tafara Rover - Navigation and Position Tracking

## Scope
This submission implements a fixed-route, timed navigation prototype for an ESP32 and L298N motor driver. The rover waits at Point A for collection, drives to Point B, waits for offloading, pivots approximately 180 degrees, returns to Point A, and repeats.

## Files
- `firmware/tafara_rover_esp32.ino` - reference ESP32 Arduino firmware for the timed state machine.
- `node-red/tafara_navigation_flow.json` - Node-RED monitoring dashboard flow (prototype; test telemetry can be injected).
- `xod/XOD_BUILD_GUIDE.md` and `xod/XOD_BUILD_PLAN.md` - XOD setup/build documentation. These are guides, not a compiled native `.xodball` project.
- `hardware/PINOUT.md` - provisional ESP32/L298N pin mapping.
- `protocol/telemetry_and_events.md` - telemetry/event message format.
- `config/navigation_config.json` - adjustable timing and route configuration reference.
- `docs/TEST_PLAN.md` and `docs/TEST_AND_SAFETY.md` - test and safety guidance.

## Important implementation status
The Node-RED flow is a monitoring prototype and was tested with sample/injected telemetry. Live ESP32-to-Node-RED MQTT integration has not yet been verified. The firmware is a reference implementation and has not been compiled or tested on the team's physical ESP32/rover. The XOD documentation is a build guide; there is no completed native `.xodball` project in this submission.

## Limitations
This design uses timed movement only. It has no GPS, compass, wheel encoders, or obstacle detection. It cannot detect true arrival at A or B or avoid obstacles. Travel and turning times must be calibrated on the actual rover, and the rover should not be operated unattended.

## Provisional pin mapping
- ENA: GPIO 25; IN1: GPIO 26; IN2: GPIO 27
- ENB: GPIO 33; IN3: GPIO 18; IN4: GPIO 19

Confirm wiring and the installed ESP32 Arduino core version before compiling or powering motors. Use a suitable motor supply and common ground; never power the motors from the ESP32 3.3V pin.
