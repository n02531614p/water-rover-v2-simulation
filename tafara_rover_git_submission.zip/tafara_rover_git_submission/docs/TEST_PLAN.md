# Test and calibration checklist

- [ ] Confirm exact ESP32 board and pin labels.
- [ ] Confirm motor supply and L298N current suitability.
- [ ] Verify outputs OFF at boot.
- [ ] Test motor direction with wheels safely raised.
- [ ] Test on clear, flat, supervised route at low speed.
- [ ] Calibrate A-to-B time over repeated runs.
- [ ] Calibrate 180-degree pivot separately.
- [ ] Calibrate B-to-A time.
- [ ] Repeat with expected payload and battery condition.
- [ ] Verify stop/wait stages and event handshakes.
- [ ] Verify MQTT telemetry reaches Node-RED.
- [ ] Verify dashboard/MQTT loss does not cause unexpected movement.

Timed-only control is open-loop and cannot verify arrival or avoid obstacles.
