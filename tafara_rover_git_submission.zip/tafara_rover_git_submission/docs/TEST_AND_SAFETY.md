# Test and safety checklist

1. Confirm exact ESP32 board and L298N wiring before connecting power.
2. Keep rover wheels off the ground for first motor-direction test.
3. Confirm left and right motors move forward when commanded forward.
4. If one motor is reversed, swap its motor leads or invert its direction logic.
5. Start with low PWM (e.g. 80/255) and short travel duration.
6. Measure the time required to travel A-to-B with the actual battery, load, and floor.
7. Calibrate the 180-degree pivot duration; 900 ms is only a starting estimate.
8. Repeat calibration with the water load and battery level expected in operation.
9. Keep a human ready to disconnect motor power during tests.

## Known limitations
- Timed movement cannot guarantee exact arrival at A or B.
- Wheel slip, uneven floors, battery voltage, motor mismatch, and load change the distance.
- No obstacle sensor means the rover will not stop for a person or object.
- Do not run unattended until safety and stopping behavior have been added and tested.
