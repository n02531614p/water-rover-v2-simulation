# Telemetry and integration protocol

MQTT topics:
- `rover/tafara/telemetry` – state and timer telemetry.
- `rover/tafara/event` – lifecycle events.

States: `WAIT_AT_A`, `COLLECTING`, `DRIVE_A_TO_B`, `WAIT_AT_B`, `OFFLOADING`, `TURNAROUND`, `DRIVE_B_TO_A`, `FAULT_STOP`.

Example JSON:
```json
{"owner":"Tafara","subsystem":"navigation","state":"DRIVE_A_TO_B","destination":"B","cycle":1,"elapsed_ms":2000,"remaining_ms":3000,"mode":"AUTONOMOUS","positioning":"FIXED_ROUTE_TIMED_ESTIMATE"}
```
Events: `AT_A_COLLECTION_START`, `COLLECTION_COMPLETE`, `AT_B_OFFLOAD_START`, `OFFLOAD_COMPLETE`, `CYCLE_COMPLETE`.

Destination is a route label, not GPS. Remaining time is an estimate. Agree handshakes with water subsystem owners. Do not commit broker passwords.
