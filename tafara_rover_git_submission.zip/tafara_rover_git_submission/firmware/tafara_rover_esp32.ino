/*
  TAFARA ROVER - AUTONOMOUS TIMED NAVIGATION
  Board: ESP32 Dev Board | Motor driver: L298N
  No GPS, compass, encoders or obstacle sensors.

  Sequence:
  A collection wait -> drive A to B -> offload wait -> pivot 180 ->
  drive back to A -> repeat.

  IMPORTANT: Timed/open-loop movement is an estimate, not true position
  tracking. Calibrate the durations on your actual rover. Test with wheels
  lifted first. Confirm pin wiring before connecting motor power.
*/
#include <Arduino.h>

// Provisional ESP32-to-L298N pin mapping. Change to match your wiring.
const int ENA = 25;  // left motor enable (PWM)
const int IN1 = 26;
const int IN2 = 27;
const int ENB = 33;  // right motor enable (PWM)
const int IN3 = 18;
const int IN4 = 19;

// Starting values only. Tune on the actual rover.
const int LEFT_SPEED = 120;       // 0..255
const int RIGHT_SPEED = 120;      // 0..255
const unsigned long DRIVE_A_TO_B_MS = 5000;
const unsigned long COLLECT_WAIT_MS = 30000;
const unsigned long OFFLOAD_WAIT_MS = 30000;
const unsigned long TURN_180_MS = 900;

// State machine
// 0 = collect at A, 1 = drive A->B, 2 = offload at B,
// 3 = turn around, 4 = drive B->A
int state = 0;
unsigned long stateStartedAt = 0;
unsigned long completedCycles = 0;
unsigned long lastTelemetryAt = 0;

void motorLeft(int speedValue) {
  int s = constrain(speedValue, -255, 255);
  digitalWrite(IN1, s > 0 ? HIGH : LOW);
  digitalWrite(IN2, s < 0 ? HIGH : LOW);
  analogWrite(ENA, abs(s));
}

void motorRight(int speedValue) {
  int s = constrain(speedValue, -255, 255);
  digitalWrite(IN3, s > 0 ? HIGH : LOW);
  digitalWrite(IN4, s < 0 ? HIGH : LOW);
  analogWrite(ENB, abs(s));
}

void stopMotors() {
  motorLeft(0);
  motorRight(0);
}

void forward() {
  motorLeft(LEFT_SPEED);
  motorRight(RIGHT_SPEED);
}

void pivot180() {
  motorLeft(LEFT_SPEED);
  motorRight(-RIGHT_SPEED);
}

const char* stateName(int s) {
  switch (s) {
    case 0: return "AT_A_COLLECTING";
    case 1: return "DRIVING_A_TO_B";
    case 2: return "AT_B_OFFLOADING";
    case 3: return "TURNING_180";
    case 4: return "DRIVING_B_TO_A";
    default: return "UNKNOWN";
  }
}

void enterState(int nextState) {
  state = nextState;
  stateStartedAt = millis();
  Serial.print("{\"event\":\"STATE_CHANGE\",\"state\":\"");
  Serial.print(stateName(state));
  Serial.print("\",\"cycles\":");
  Serial.print(completedCycles);
  Serial.println("}");
}

void setup() {
  Serial.begin(115200);
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  stopMotors();
  enterState(0);
}

void loop() {
  unsigned long elapsed = millis() - stateStartedAt;

  switch (state) {
    case 0: // Wait at A for collection
      stopMotors();
      if (elapsed >= COLLECT_WAIT_MS) enterState(1);
      break;

    case 1: // Travel A to B
      forward();
      if (elapsed >= DRIVE_A_TO_B_MS) {
        stopMotors();
        enterState(2);
      }
      break;

    case 2: // Wait at B for offloading
      stopMotors();
      if (elapsed >= OFFLOAD_WAIT_MS) enterState(3);
      break;

    case 3: // Pivot approximately 180 degrees
      pivot180();
      if (elapsed >= TURN_180_MS) {
        stopMotors();
        enterState(4);
      }
      break;

    case 4: // Return B to A (forward after pivot)
      forward();
      if (elapsed >= DRIVE_A_TO_B_MS) {
        stopMotors();
        completedCycles++;
        enterState(0);
      }
      break;
  }

  if (millis() - lastTelemetryAt >= 1000) {
    lastTelemetryAt = millis();
    Serial.print("{\"state\":\"");
    Serial.print(stateName(state));
    Serial.print("\",\"elapsed_ms\":");
    Serial.print(millis() - stateStartedAt);
    Serial.print(",\"cycles\":");
    Serial.print(completedCycles);
    Serial.println("}");
  }
}
