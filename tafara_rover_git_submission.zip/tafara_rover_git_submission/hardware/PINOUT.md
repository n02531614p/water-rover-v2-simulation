# Provisional ESP32 + L298N wiring

| L298N | Example ESP32 GPIO | Purpose |
|---|---:|---|
| ENA | 25 | Left PWM |
| IN1 | 26 | Left direction |
| IN2 | 27 | Left direction |
| ENB | 33 | Right PWM |
| IN3 | 18 | Right direction |
| IN4 | 19 | Right direction |
| GND | GND | Common ground |

Confirm the exact ESP32 and L298N before wiring. Remove ENA/ENB jumpers when using PWM. Share ESP32/L298N ground. Use a separate rated motor supply; never power motors from ESP32 3.3 V. Check regulator jumper and motor stall current.
